# **gmpz**  Dyalog APL class and helper operator **GI**
*Backed by GMP mpz calls (libgmp)  •  Nov 2026 Edition (2026-11-17)*

For Dyalog APL v20 or later (developed with v21) and GMP 6.3 or later. [Tested on macOS; designed for macOS, Linux and Windows]

# **Setup**

```
]load gmpz/gmpz
⎕FR ⎕PP← 1287 34        ⍝  Optional. Convenient for entering large (64-bit) integer constants.
```

* Dyalog APL v20 or later (64-bit) and the GMP shared library (libgmp).
* GMP 6.3 or later is required — PrevPrime uses mpz\_prevprime, which does not exist in earlier GMP versions, and the class binds all its routines on load (an older library fails with gmpLoadÊ).
* Inside the class, ⎕IO ⎕ML ⎕PP ⎕FR are 0 1 34 1287. Set ⎕FR←1287 in your own session if you want to type 64-bit integers directly. Numeric literals of more than 16 digits are read using the ⎕FR in force when the code is fixed or entered, so for big constants in saved code, use strings.

# **1\.  Creating and reading values**

```
   a← ⎕NEW gmpz                         ⍝ 0
   a← ⎕NEW gmpz ¯2                      ⍝ from an APL integer
   a← ⎕NEW gmpz '1234567 89012345678'   ⍝ from a string ('¯' => '-'). Blanks ok!
   a← ⎕NEW gmpz ('bee cafe' 16)         ⍝ from a string in base 16 (base ∊ 2…62)
   a← gmpz.New0                         ⍝ Alternative: new object, value 0
   a← gmpz.New '999999999'              ⍝ Alternative: new object from a value
   b← 16 gmpz.New 'ff'                  ⍝ ... works with a base on the left
   16 b.Set 'bee cafe'                  ⍝ Set b to a new string value (in base 16)
   b.Set a                              ⍝ copy the value of another gmpz into b
   c← a.Copy                            ⍝ a new, independent gmpz with a's value
   ⌷b                                   ⍝ value of b in string form
```

**Assignment aliases.** `b← a` makes b and a the *same* object, so `b.Inc` changes a too. Use `b← a.Copy` for an independent copy.

| Call | Result |
| :----------------------------------------- | :---- |
| `str← ⌷a` | *a* in base 10 as a string (any length). |
| `a.Set value`, `base a.Set value` | Overwrite **a** with value (base applies to strings only, default 10). Returns **a** itself (shy), so calls can be chained. |
| `c← a.Copy` | A new gmpz with the same value. |
| `int← a.Int64` | a as a signed C long (64-bit on Unix/macOS), as an APL integer. Error (badIntÊ) if it doesn't fit. |
| `int← a.IntDF` | a as an APL integer in decimal-float form: exact up to 34 digits (±(10\*34−1)). Error (badIntÊ) if it has more digits. |
| `ok int← a.VFI` | `1 n` if a fits in 34 digits (as IntDF), else `0 0`. Never errors. |
| `str← a.GetInBase n` | **a** as a string in base n (2 ≤ n ≤ 62). |
| `str← [base] gmpz.Get b` | b (a gmpz, an APL integer or a *decimal* string) as a string in the base (default 10). |
| `int← a.StrLen` | Number of characters in ⌷a, including the leading ¯. Same as ≢⌷a, without building the string. |
| `int← a.StrLenInBase n` | Same as ≢a.GetInBase n, for 2 ≤ n ≤ 62. |
| `int← a.BitLen` | Minimum number of bits to hold **a** in two's complement, *including the sign bit*: 0 is 1, 7 is 4, 8 is 5, ¯8 is 4, ¯1 is 1. Equals ≢a.Bits. |
| `int← a.Signum` | ¯1, 0 or 1. |
| `bool← a.Even`, `a.Odd` | 1 or 0 (visible results). |
| `bool← a.Bit[i1 i2…]` | Read bits. Honours ⎕IO. See §5. |
| `a.Bit[i1 i2…]← bool` | Write bits at specified indices. Honours ⎕IO. |
| `bool← a.Bits` | **a**'s value efficiently returned as a boolean vector in two's complement, sign bit first. |
| `a.Bits← bool` | **a**'s value efficiently set (replaced) from a boolean vector (leading bit is the sign). |
| `int← a.ptr` | Address of the underlying GMP object. Be careful! |

**Int64 or IntDF?** Int64 is the machine integer (fast, 64-bit). IntDF is "as big as an APL decimal float can hold exactly" (34 digits) and needs `⎕FR←1287` in your session to display or compute with such values exactly. Use `VFI` to test safely.

**Memory:** A gmpz object and its GMP storage are allocated for you. They are freed automatically when the object goes out of scope, when ⎕EX is executed on the object, when the workspace is cleared, or when the session ends. The random-number state is created the first time you call Rand, RandB or RandSeed.

Set **DEBUG←1** in the class source to trace allocations and frees; **DEBUG←2** also traces the random state and the library bindings.

**Not saved with the workspace.** Objects hold raw C pointers: they do not survive `)SAVE`/`)LOAD` (or ⎕OR). Re-create them after loading.

**Resources.** GMP stops the whole process if it runs out of memory. Methods such as Fac, Pow, Shift and RandB accept arguments up to 2\*64−1, so a mistyped argument (say `c.Fac 1E12`) can end your session. Check sizes first.

# **2\.  The operating model**

Most methods are in place. The receiver is overwritten and returned (shy).

```
   c.Add b             ⍝ c ← c + b
   a c.Add b           ⍝ c ← a + b   (c is only the destination)
   ⌷(c.Set 5).Inc      ⍝ results are shy and return the receiver, so calls chain: c is now 6
```

Operands (a, b) may each be:

* a gmpz object (used directly, never copied);
* an APL integer (positive or negative, a whole-number scalar of up to 34 digits when ⎕FR←1287; beyond a C long it is converted through its decimal string — use a string for anything bigger);
* an integer string ('¯' is accepted as a minus sign).

An operand may repeat another operand or the receiver: `c c.Mul c` is safe.

Non-gmpz operands are copied into three hidden scratch gmpz objects, so don't rely on their values between calls. Methods use :Hold around the shared scratch objects, so concurrent threads queue for them.

A non-integer APL number signals badAplÊ, as does a numeric vector (including a boolean vector). A single scalar 0 or 1 is just an integer.

**Which methods take what.**

* Dyadic arithmetic (Add, Sub, Mul, Div, DivRem, Gcd, Lcm, Pow, PowM, Invert, And, Or, Xor, Cmp…, Jacobi): `[a] c.Op b`; the left operand defaults to the receiver.
* Left argument required: **Res** and **Shift**.
* **Niladic, in place:** Neg, Abs, Inc, Dec. To set c to −b, write `(c.Set b).Neg`; to set c to \|b, `(c.Set b).Abs`.
* **Right argument only** (a value is built from it, so it does not default to the receiver): Fac, NextPrime, PrevPrime, Rand, RandB, ProbabPrime. To use the receiver, pass it: `c.NextPrime c`.
* **Mutating bit methods** (SetBit, ClrBit, Flip) act on the receiver only. To change a bit of another gmpz, call the method on that object.

# **3\.  Arithmetic methods (in place)**

\[a\]: if a is omitted, it defaults to the receiver c.

| Method | Meaning | Notes |
| :----------------------------------------------------------------------------------------------- | :----------- | :---------- |
| `[a] c.Add b` | `c ← a + b` |  |
| `[a] c.Sub b` | `c ← a − b` |  |
| `[a] c.Mul b` | `c ← a × b` |  |
| `[a] c.Div b` | `c ← ⌊a ÷ b` | Floored (rounds toward ¯∞), like APL's `⌊a÷b.` Signals divZÊ if b is 0\. |
| `rem← [a] c.DivRem m` | `c ← ⌊a÷m, returns rem← m\|a` | Same floored quotient as Div. The remainder is returned as a new **gmpz** object (shy), not as an APL integer. The divisor may be a **gmpz**, an APL integer or a string — it does not have to fit in 64 bits (the fast unsigned path is used only when it is a non-negative APL integer ≤ 2\*64-1). divZÊ if m is 0. |
| `m c.Res b` | `c ← m\|b` | APL residue, floored (sign follows m). 0\|b is b. Dyadic only. |
| `[a] c.Gcd b` | `c ← a∨b` | ≥ 0\. Greatest common divisor. |
| `[a] c.Lcm b` | `c ← a∧b` | ≥ 0\. Least common multiple. |
| `[a] c.Pow n` | `c ← a\*n` | n must be a non-negative APL integer (not a string or gmpz), and must fit in a C unsigned long (powÊ otherwise). |
| `[a] c.Pow ÷n` | `n-th root of a, truncated toward 0` | Same as ⌊a\*÷n for a≥0\. n a positive integer. If a\<0, n must be odd. |
| `[a] c.PowM (e m)` | `c ← m\|a*e` | Modular exponentiation. e and m may be gmpz, integer or string. A negative exponent or a negative modulus signals powÊ (modulus 0 signals divZÊ). |
| `rc← [a] c.Invert m` | `c ← a⁻¹ mod m` | Returns 1 if the inverse exists, 0 if not (then c is meaningless). m>0 (divZÊ for 0, powÊ for negative). |
| `i c.Shift b` | `c ← b × 2*i` | Binary shift. i\>0 left, i\<0 right (truncating toward zero). Dyadic only. i may be an integer, an integer string or a gmpz; non-integers signal shiftÊ. |
| `c.Neg` | `c ← −c` | Niladic. For c ← −b: `(c.Set b).Neg`. |
| `c.Abs` | `c ← \|c` | Niladic. For c ← \|b: `(c.Set b).Abs`. |
| `c.Fac n` | `c ← !n` | n ≥ 0; n may be an integer, string or gmpz. n must be ≤ 2\*64-1 (Windows: 2\*32-1), else facBadÊ. Large results are limited only by memory. |
| `c.Inc` | `c ← c+1` | Niladic. |
| `c.Dec` | `c ← c−1` | Niladic. |
| `bool← c.Divisible b` | `1 if b divides c, else 0` | b=0: true only if c is 0\. Visible 0/1 result. |

```
    c← ⎕NEW gmpz
    2 c.Pow 200                    ⍝ c ← 2*200
    c.Mul 3                        ⍝ c ← c × 3
    1000 c.Res c                   ⍝ c ← 1000|c
    ¯7 c.Shift c                   ⍝ c ← c ÷ 2*7, truncated toward 0. (Shift bits right)
    c.Pow ÷2                       ⍝ c ← √c (truncated toward 0)
    c.Fac 100                      ⍝ c ← !100
    r← ⎕NEW gmpz
    7 r.PowM 128 13                ⍝ r ← 13|7*128
    c.Neg                          ⍝ c ← -c
```

**Floored division:** Div, DivRem and Res are floored (round toward ¯∞), matching APL's ⌊ and ⍺\|⍵, so a \= (m×⌊a÷m) \+ m\|a for any signs. This differs from C, where integer division (/) truncates toward zero. Right Shift truncates toward zero, so that identity holds for Div/Res but not for right Shift. The n-th root, Pow ÷n, also truncates toward zero, which only matters for negative a with odd n.

# **4\.  Comparison**

There are no \< or \> methods — use the named forms below or use `<GI`, `>GI`, etc. If a is omitted, it defaults to the receiver. If b is an APL integer in the signed 64-bit range, a faster signed-integer comparison is used.

| Method | APL equivalent | Returns |
| :---- | :---- | :---- |
| `[a] c.Cmp b` | `×a−b` | `¯1, 0 or 1` |
| `[a] c.Lt b` | `a < b` | `0 or 1` |
| `[a] c.Le b` | `a ≤ b` | `0 or 1` |
| `[a] c.Eq b` | `a = b` | `0 or 1` |
| `[a] c.Ne b` | `a ≠ b` | `0 or 1` |
| `[a] c.Ge b` | `a ≥ b` | `0 or 1` |
| `[a] c.Gt b` | `a > b` | `0 or 1` |

```
   c.Gt 100                       ⍝ is c > 100 ?
1
   '1234567890123456' c.Eq y      ⍝ string vs gmpz
0
```

# **5\.  Retrieving and manipulating bits**

a.Bit\[ix\] reads or writes individual bits in place. The least significant bit is at index 0 if ⎕IO=0, and at index 1 if ⎕IO=1.

```
a← ⎕NEW gmpz 15             ⍝ 1111₂
a.Bit[0 1 2]← 0             ⍝ a is now 8 (1000₂)
a.Bit[3]                    ⍝ → 1
a.Bit[0 1 2]← 1 0 1         ⍝ set several bits at once → a is 13 (1101₂)
a.Bit[0 2 3]                ⍝ read several bits → 1 1 1
a.Bit[2]← 0                 ⍝ clear bit 2 → a is 9 (1001₂)
a.BitLen                    ⍝ 5: bits in two's complement, including the sign bit
a.Bits                      ⍝ 0 1 0 0 1   (sign bit first, then most-significant first)
```

| Form | Meaning |
| :---- | :---- |
| a.Bit\[n\] | Read bit n (0 or 1). |
| a.Bit\[n\]← 1\|0 | Set or clear bit n. |
| a.Bit\[n1 n2 n3\] | Read several bits. |
| a.Bit\[n1 n2 n3\]← 1 0 1 | Set or clear several bits (one value per index, or one value for all). |
| a.Bits | **All** bits as a boolean vector in two's complement, sign bit first (the reverse of a.Bit\[⍳a.BitLen\]). |
| a.Bits← 1 0 1 | Replace **all** the bits of object *a*; the leading bit is the sign (`a.Bits← ,1` is ¯1; an empty vector is 0). |
| a.ExportBits w | As a.Bits but exactly w bits wide (sign-extended), w ≥ a.BitLen. `0` means the minimum. |
| a.ImportBits bits | Same as `a.Bits← bits`. |

Values assigned to bits must be 0 or 1 (badBitValÊ). Setting a bit beyond the current length to 1 is valid; the object grows automatically. Clearing high-order bits shrinks it.

Note: Although GMP stores mpz_t values internally in sign-magnitude form, all bitwise operations and shifts emulate infinite-width two's complement arithmetic. Non-negative integers are treated as having an infinite prefix of 0 bits and negative integers an infinite prefix of 1 bits, while left and right bit shifts correspond to exact multiplication and truncating division by 2\*b.

## **Whole-number bitwise operations (in place)**

| Method | Meaning |
| :---- | :---- |
| \[a\] c.And b | c ← a ∧ b, bit by bit |
| \[a\] c.Or b | c ← a ∨ b, bit by bit |
| \[a\] c.Xor b | c ← a ≠ b, bit by bit |

## **Bit methods (alternatives to the Bit property)**

All of these honour the caller's ⎕IO for their bit positions. A position below ⎕IO signals badBitIxÊ.

| Method | Meaning |
| :---- | :---- |
| `bool← [a] c.TestBit n` | Returns bit n. A visible result; `a` may be any operand (read-only). |
| `val← c.SetBit n [val]` | Sets bit n to val (default 1): `c.SetBit 5` or `c.SetBit 5 0`. Receiver only; shy. |
| `bit← c.ClrBit n` | Clears bit n (sets it to 0). Receiver only; shy. |
| `bit← c.Flip n` | Complements bit n, and returns its new value. Receiver only; shy. |
| `pos← [a] c.Iota bit` | Index of the lowest bit equal to bit (0 or 1), counted in your ⎕IO. Visible result. |
| `pos← [a] c.Scan (start bit)` | Like Iota, but begins the search at index start (in your ⎕IO). Visible result. |

Iota and Scan return **2\*64−1** (2\*32−1 on Windows), *not* adjusted for ⎕IO, when there is no such bit.

# **6\.  Random numbers**

Uses GMP's Mersenne Twister; its state is created on first use of a random number function and seeded from system entropy by default (it can be changed via RandSeed). Rand and RandB are ⎕IO-sensitive — in ⎕IO←1 Rand returns 1…b and RandB returns 1…2\*n (in ⎕IO←0, 0…b-1 and 0…2\*n-1).

```
   c← ⎕NEW gmpz '123456789012345678901234567890'
   gmpz.RandSeed 42                            ⍝ seed (like gmp_randseed_ui)
   r← ⎕NEW gmpz
   r.Rand c                                    ⍝ r ← uniform in 0 ≤ r < c
   ⌷r.RandB 256                                ⍝ r ← uniform in 0 ≤ r ≤ 2*256−1
```

| Method | Meaning |
| :---- | :---- |
| `r.Rand b` | r ← uniform in \[0, b); b may be gmpz, integer or string; must be positive (randÊ). |
| `r.RandB n` | r ← uniform in \[0, 2\*n); n ≥ 0. |
| `gmpz.RandSeed u` | Seeds with an unsigned 64-bit u; returns the old seed (shy) as a string. RandSeed 0 reseeds from system entropy. |

Only one random state exists for all objects; reseeding anywhere affects every later Rand and RandB.

# **7\.  Primes and number theory**

```
⍝  rc: 2 definitely prime, 1 probably prime, 0 not prime
   rc← c.ProbabPrime ⍬        ⍝ ⍬ or 0: default of 24 Miller-Rabin reps (the argument itself is required)
   rc← c.ProbabPrime 15       ⍝ 15 reps (15–50 is reasonable)
   c.NextPrime n              ⍝ c ← next prime > n
   c.PrevPrime n              ⍝ c ← greatest prime < n  (noPrevPrimeÊ if n ≤ 2)
   (c rc)← c.PrevPrime2 n     ⍝ Like PrevPrime, but also returns rc: 2 definitely, 1 probably, 0 none (no error)
   rc← [a] c.Jacobi b         ⍝ Jacobi symbol (a/b): ¯1, 0 or 1. b must be odd (badAplÊ if even).
   rc← [a] c.Invert m         ⍝ modular inverse (see §3)
```

PrevPrime relies on GMP's mpz\_prevprime (GMP 6.3+), which sets c to the greatest prime strictly less than n and itself returns 2, 1 or 0\. PrevPrime2 returns (mpz rc) where rc is that GMP return code; plain PrevPrime signals noPrevPrimeÊ when the code is 0.

c is the number being tested for ProbabPrime, Jacobi (when a is omitted) and Divisible.

# **8\.  The GI operator: primitive-style, non-destructive**

GI wraps the methods so they read like APL primitives. Arguments are never modified; a new gmpz is returned (comparisons, and several monadic and dyadic forms marked below, return plain values). GI is also defined in the namespace that holds gmpz, so it can be used from anywhere. Every result is a fresh object, so it never changes under a later GI call.

```
    x← 2 *GI 100                   ⍝ 2*100
    y← x +GI 1                     ⍝ x + 1
    z← 10 |GI y                    ⍝ 10|y   (left is the modulus)
    ⌷ !GI 30                       ⍝ factorial, shown as a string (⌷ on a gmpz is its string form)
    ⊤GI 30                         ⍝ plain string of 30 (a GI call returning a string, not an object)
    7 <GI x                        ⍝ comparison → 0/1
```

| Dyadic | Meaning | Monadic | Meaning |
| :---- | :---- | :---- | :---- |
| `a +GI b` | a+b | `-GI b` | negate |
| `a -GI b` | a−b | `\|GI b` | absolute value |
| `a ×GI b` | a×b | `?GI b` | random in \[0, b) if b≥0; in \[0, 2\*\|b) (RandB) if b\<0 |
| `a ÷GI b` | ⌊a÷b (floored) | `!GI b` | factorial |
| `a ÷∘\|GI b` | DivRem: a 2-vector of new gmpz's, see note | `×GI b` | signum (plain integer) |
| `a *GI b` | a\*b (b may be ÷n) | `<GI b` | b−1 |
| `a ∨GI b` | gcd | `>GI b` | b+1 |
| `a ∧GI b` | lcm | `≢GI b` | string length (b.StrLen, plain integer) |
| `a \|GI b` | a\|b (a is the modulus) | `⍎GI b` | b as an APL integer (IntDF; error if it does not fit) |
| `a ⌽GI b` | shift b by a bits | `⎕VFI GI b` | `ok int` as b.VFI, never errors |
| `a *∘\|GI (e m)` | m\|a\*e (PowM) | `⌷GI b` | b as a two's complement bit vector (b.Bits) |
| `a ⍳GI i` | position of the lowest bit of a equal to i (0 or 1); 2\*64−1 if none (plain integer) | `⊤GI b` | b as a decimal string |
| `a ⌷GI b` | bit a of b (b.Bit\[a\]; plain 0/1) | `⊥GI b` | a new gmpz holding a copy of b |
| `a <GI b` … | also ≤ \= ≥ \> ≠, returning 0 or 1 |  |  |
| `a ⊤GI b` | b (gmpz, integer or decimal string) as a *string* in base a | | |
| `a ⊥GI b` | a new gmpz from the string b read in base a | | |
| `a ≢GI b` | length of the string of b in base a (plain integer) | | |

Note: `(mpz mpz)← a ÷∘|GI b` calls DivRem, returning `((a÷b), (b|a))`, floored, both new gmpz's.

Use the gmpz methods directly when you want to avoid allocating a new object per operation. An unsupported glyph gives unknownÊ.

# **9\.  Errors**

Errors in public methods are trapped and re-signalled from your line, so ⎕DMX points at your code.

| Name | EN | Meaning |
| :---- | :---- | :---- |
| noGmpÊ | 22 | GMP library not found |
| gmpLoadÊ | 11 | A GMP routine failed to bind (library older than 6.3?) |
| badInitÊ | 11 | Unable to create object |
| badAplÊ | 11 | Invalid APL value (not a whole-number scalar, or too many digits), or a base outside 2…62 |
| badObjÊ | 11 | Can't convert to a gmpz (e.g. bad string, released object) |
| badIntÊ | 11 | Doesn't fit the requested APL integer type (Int64: C long; IntDF: 34 digits) |
| badBitsÊ | 11 | Bits← vector contains something other than 0 and 1 |
| badBitValÊ | 11 | Bit value must be 0 or 1 |
| badBitIxÊ | 3 | Invalid bit index (below ⎕IO, or too large) |
| baseXtraÊ | 11 | A base was given with a value that is not a string |
| divZÊ | 11 | Division by 0 |
| powÊ | 11 | Invalid power / root / modulus |
| shiftÊ | 11 | Shift value must be an integer |
| facBadÊ | 11 | Factorial of a negative integer, a non-integer, or a value over 2\*64-1 (Windows: 2\*32-1) |
| primeÊ | 11 | Bad reps argument for ProbabPrime |
| noPrevPrimeÊ | 11 | PrevPrime of a number ≤ 2 |
| propSetÊ | 11 | Tried to assign to a.Bits\[i\]; use a.Bit\[i\] |
| randSeedÊ | 11 | Seed can't be converted to an unsigned integer |
| randÊ | 11 | Arg must be positive (Rand bound ≤ 0, or RandB bits \< 0\) |
| randStateÊ | 11 | Unable to initialise random # state |
| randActiveÊ | 911 | Internal logic error: only one randState instance is allowed. |
| unknownÊ | 11 | Unsupported glyph in GI |

# **10\.  Quick reference and gotchas**

1. In `a c.Op b`, **c** is the destination and is overwritten and **a** is the left operand; in `c.Op b` the receiver is both the left operand and the destination.
2. Res (**\|**) and Shift (**⌽**) require a left argument; most other dyadic methods default it to the receiver. Neg, Abs, Inc and Dec are niladic. Fac, NextPrime, PrevPrime, Rand, RandB and ProbabPrime take only a right argument.
3. **Shy results:** the in-place arithmetic methods, DivRem, Fac, SetBit, ClrBit, Flip, Rand, RandB and RandSeed print nothing in the session. Assign the result, or use ⌷ to see a value. Predicates and queries (Even, Odd, Divisible, TestBit, Iota, Scan, ProbabPrime, Cmp and friends, Signum, Jacobi, Invert) are visible.
4. **Pow exponent** must be a plain APL non-negative integer *n* or *÷n* (for roots). Negative exponents are invalid.
5. **DivRem divisors** may be any supported operand type and must be non-zero (divZÊ if **0**).
6. Use `⌷a` to see the final (string) value. It is more efficient to keep working with gmpz objects, so that no unnecessary conversions to and from strings are needed.
7. Strings may use the high minus **¯** on input; it is converted to **-** by gmpz utilities.
8. The base (2 through 62) can be specified when importing numeric strings; it is invalid for other operand types.
9. `a.Int64` only succeeds when the value fits a C long (signed 64-bit); `a.IntDF` allows up to 34 digits. Use **VFI** to test safely. Set `⎕FR←1287` in your session if you manipulate integers beyond 2\*53.
10. **Copy, don't assign:** `b← a` aliases; `b← a.Copy` copies.
11. **⎕IO:** only the bit-position methods (Bit, TestBit, SetBit, ClrBit, Flip, Iota, Scan) and Rand/RandB depend on ⎕IO.
12. Objects are lost on `)SAVE`/`)LOAD`; huge arguments can exhaust memory and stop the session (see §1).

# 

# **Appendix: Encrypt a Message Using Simplified RSA Key**

Implement a simplified[^1] **RSA key generation, encryption, and decryption** workflow.
This demonstrates the core lifecycle of GMP integers:
initialization, random prime generation, modular arithmetic, modular inverse, and memory cleanup.

## **Example Code: ___GmpzExample___**

```
∇ ret← GmpzExample msgIn
⍝  To run:
⍝    ret@CV← GmpzExample msgIn@CV
⍝  msgIn: An APL string that can be encoded in fewer than modBits (1024) bits (UTF-8)
⍝  Success if it returns a happy message

⍝--1 DECLARATIONS AND INITIALIZATION ------------------------------------------------------------------
⍝  Declarations, definitions, etc.
⍝  Declare helper functions
     ; HS; Tidy
⍝  Declare all mpz_t variables
     ; p; q; n; phi; e; d; msg; cipher; decrypted
⍝  Declare # of bits in the modulus
     ; modBits

⍝  Define helper fn HS (Unicode => hexadecimal String)
⍝  HS:    str@CV← [[1: encrypt | 0: decrypt]] ∇ str@CV
   HS← {⎕IO← 0 ⋄ ⍺← 1 ⋄ hd← ⎕D,'abcdef' ⋄ U← 'UTF-8'∘⎕UCS
     ⍺=1: ,hd[⍉16 16⊤U ⍵] ⋄ U 16⊥hd⍳⍉t⍴⍨2,⍨2÷⍨≢t← ⎕C ⍵~' '
   }
⍝  Define helper fn Tidy: Print long results in nice rows of 64 bytes, with left margin of  4 spaces
⍝  Tidy:    ∇ str@CV
   Tidy← 64 { ⍺← ⍬ ⋄ p← ⍵⍵⍴'' ⋄ ⍺⍺≥ ≢⍵: ↑⍺,⊂p, ⍵ ⋄ (⍺, ⊂p, ⍺⍺↑⍵) ∇ ⍺⍺↓⍵ } 4

⍝  Initialize all mpz variables
   p q n phi e d msg cipher decrypted← gmpz.New¨9⍴0

⍝  Initialise modBits: max # of bits in the modulus.  Must be even.
   modBits← 1024                                             ⍝ Best practices: modBits∊ 2048 4096
   'Modulus must be even number of bits' ⎕SIGNAL 11/⍨ 0≠ 2|modBits

⍝--2 GENERATE PUBLIC AND PRIVATE KEYS -----------------------------------------------------------------
⍝  Initialize random number generator with entropy
⍝     (automatic/default when RandB is first called)
⍝   Generate two distinct 512-bit probable primes (p and q)

⍝  p...
   p.(NextPrime RandB) modBits÷2

⍝  q...
   :Repeat  ⍝⍝ Ensure p ≠ q
      q.(NextPrime RandB) modBits÷2
   :Until q.Ne p

⍝  Compute the  modulus n: n ← p × q, where n.BitLen is approx modBits (may be a bit smaller)
   p n.Mul q

⍝  Compute Euler's totient: phi← (p - 1) × (q - 1)
   p.Dec phi.Mul q.Dec                                       ⍝ p is now p-1, q is now q-1

⍝  Set public exponent e = 65537 and compute private exponent
   e.Set 65537
   :If 0=e d.Invert phi                                      ⍝ Invert: d← e*-1 mod phi
      ret← 'Error: e and phi are not coprime.'  ⋄ :Return
   :EndIf

⍝- 3 IMPORT MSG -----------------------------------------------------------------------------------
⍝  Import the plaintext msgIn ==> msg, where msgIn will be encoded via UTF-8 for simplicity.
   16 msg.Set HS msgIn

   :If msg.BitLen≥ n.BitLen                                  ⍝ length limited for demo...
      ret← 'Your message is too big' ⋄  :Return
   :EndIf

⍝--4 ENCRYPT --------------------------------------------------------------------------------------
⍝  Encrypt: cipher ← (msg * e) mod n
   msg cipher.PowM e n

⍝--5 DECRYPT -------------------------------------------------------------------------------------
⍝  Decrypt: decrypted ← (cipher * d) mod n
   cipher decrypted.PowM d n

⍝--6 PRINT AND VERIFY-----------------------------------------------------------------------------
⍝  Print results
   ⎕← 'Public Modulus (n): '  ⋄ ⎕← Tidy n.GetInBase 16
   ⎕← 'Encrypted Cipher:   '  ⋄ ⎕← Tidy cipher.GetInBase 16
   ⎕← 'Decrypted Message:  '  ⋄ ⎕← Tidy 0 HS decrypted.GetInBase 16

⍝  Verify correctness
   :If 0=msg.Cmp decrypted
      ret← 'Success: Decrypted message matches original'
   :Else
      ret← 'Failure: Decrypted message does not match original'
   :EndIf

⍝--7 FREE STUFF ----------------------------------------------------------------------------------
⍝  Free all allocated memory
⍝  gmpz does it all for you!
```

### OUTPUT [^2]
```
      GmpzExample  '🙂 This is a cat 🙂'
Public Modulus (n):
    7c09b76d3dabfc23419a94a9db4452e891747b45e86a0ef162c3712ce1a53c31
    ...
Encrypted Cipher:
    646d47879ff5b113e3ec0172062eaeaec75ac21d5630fa815c6f8e91b49569f1
    ...
Decrypted Message:
    🙂 This is a cat 🙂
Success: Decrypted message matches original

```

[^1]:  RSA encryption is still useful today, provided you use 2048- or, preferably, 4096-bit encryption.
[^2]:  The output is abridged (...) for pedagogical purposes.
